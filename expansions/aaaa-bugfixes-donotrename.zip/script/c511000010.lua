--Ritual of the Matador
function c511000010.initial_effect(c)
	aux.AddRitualProcGreaterCode(c,511000009)
end
