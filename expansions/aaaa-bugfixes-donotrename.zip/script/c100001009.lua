--リトマスの死儀式
function c100001009.initial_effect(c)
	aux.AddRitualProcGreaterCode(c,100001010)
end
