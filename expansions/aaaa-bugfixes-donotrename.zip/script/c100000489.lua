--黒竜降臨
function c100000489.initial_effect(c)
	aux.AddRitualProcGreaterCode(c,100000488)
end
